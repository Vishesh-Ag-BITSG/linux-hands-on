#!/bin/bash

for n in {1..100};
do
	echo "Hello World $n"
done
